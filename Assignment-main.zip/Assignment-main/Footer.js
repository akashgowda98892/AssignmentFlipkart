// Footer.js
import React from 'react';

const Footer = () => {
  return (
    <footer style={{ position: 'fixed', bottom: 0, width: '100%', background: '#f4f4f4', padding: '10px', textAlign: 'center' }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start' }}>
        <div style={{ marginBottom: '20px' }}>
          <p style={{ fontSize: '20px' }}>a</p>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
        <hr style={{ border: '1px solid black', width: '100%' }} />
        <div style={{ marginBottom: '20px' }}>
          <p style={{ fontSize: '20px' }}>b</p>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
        <hr style={{ border: '1px solid black', width: '100%' }} />
        <div style={{ marginBottom: '20px' }}>
          <p style={{ fontSize: '20px' }}>c</p>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </div>
        <img src="your_image_url" alt="Your Image" style={{ width: '50px', height: '50px', marginTop: '20px' }} />
      </div>
    </footer>
  );
};

export default Footer;
