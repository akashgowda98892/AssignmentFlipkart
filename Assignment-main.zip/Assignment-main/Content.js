// Content.js
import React from 'react';

const Content = () => {
  return (
    <div style={{ width: '80%', padding: '10px' }}>
      <div style={{ borderBottom: '1px solid blue', paddingBottom: '10px' }}>
        <h2>Display</h2>
        <p style={{ fontSize: '14px' }}>Page to configure all the company details</p>
      </div>
      <form style={{ marginTop: '20px', display: 'flex', justifyContent: 'space-between' }}>
        <div style={{ width: '48%' }}>
          <div style={{ marginBottom: '20px' }}>
            <label>Logo:</label>
            <br />
            <input type="file" />
            <button style={{ marginLeft: '10px' }}>Change</button>
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label>Org ID:</label>
            <br />
            <input type="text" />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label>Org Name:</label>
            <br />
            <input type="text" />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label>No. of Integrations:</label>
            <br />
            <select>
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </div>
          {/* Add other form fields here */}
        </div>
        <div style={{ width: '48%' }}>
          <div style={{ marginBottom: '20px' }}>
            <label>City Name:</label>
            <br />
            <input type="text" />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label>Team Name:</label>
            <br />
            <input type="text" />
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label>Team Count:</label>
            <br />
            <select>{/* Options for team count */}</select>
          </div>
          <div style={{ marginBottom: '20px' }}>
            <label>Go Live Month:</label>
            <br />
            <select>{/* Options for go live month */}</select>
          </div>
          {/* Add other form fields here */}
        </div>
      </form>
    </div>
  );
};

export default Content;
