// Sidebar.js
import React from 'react';

const Sidebar = () => {
  return (
    <div style={{ width: '20%', background: '#f4f4f4', padding: '10px', opacity: '0.8' }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
        <p style={{ marginBottom: '20px' }}>Services Offered</p>
        <p style={{ marginBottom: '20px' }}>Org Setup</p>
      </div>
      <div style={{ display:
// Sidebar.js
import React from 'react';

const Sidebar = () => {
  return (
    <div style={{ width: '20%', background: '#f4f4f4', padding: '10px', opacity: '0.8' }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end' }}>
        <p style={{ marginBottom: '20px' }}>Services Offered</p>
        <p style={{ marginBottom: '20px' }}>Org Setup</p>
      </div>
      <div style={{ display:
