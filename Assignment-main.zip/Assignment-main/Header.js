// Header.js
import React from 'react';

const Header = () => {
  return (
    <header style={{ background: 'white', color: '#000', padding: '10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', border: '1px solid lightgrey' }}>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <img src="flipkart_logo.png" alt="Flipkart Logo" style={{ width: '50px', height: '50px' }} />
        <div style={{ marginLeft: '10px' }}>
          <p style={{ fontSize: '14px', margin: '0' }}>Pay cycle: 31-May-2021 to 31-June-2021</p>
          <div style={{ position: 'relative' }}>
            <select style={{ position: 'absolute', top: '100%', left: '0', marginTop: '5px' }}>
              <option value="Amazon Pvt Ltd">Amazon Pvt Ltd</option>
              <option value="option2">Option 2</option>
              <option value="option3">Option 3</option>
            </select>
          </div>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center' }}>
        <img src="support_logo.png" alt="Support Logo" style={{ width: '30px', height: '30px', marginRight: '10px' }} />
        <img src="notification_logo.png" alt="Notification Logo" style={{ width: '30px', height: '30px', marginRight: '10px' }} />
        <div style={{ width: '40px', height: '40px', backgroundColor: 'green', borderRadius: '50%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
          <p style={{ color: '#fff', fontWeight: 'bold' }}>R</p>
        </div>
      </div>
    </header>
  );
};

export default Header;
